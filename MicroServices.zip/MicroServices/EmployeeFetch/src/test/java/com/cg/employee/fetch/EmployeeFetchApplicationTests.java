package com.cg.employee.fetch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeFetchApplicationTests {

	@Test
	void contextLoads() {
	}

}
