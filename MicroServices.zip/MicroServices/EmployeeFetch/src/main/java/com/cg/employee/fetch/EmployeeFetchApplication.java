package com.cg.employee.fetch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeFetchApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeFetchApplication.class, args);
	}

}
