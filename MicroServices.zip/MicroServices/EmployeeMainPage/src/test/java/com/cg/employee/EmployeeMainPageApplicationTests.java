package com.cg.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeMainPageApplicationTests {

	@Test
	void contextLoads() {
	}

}
