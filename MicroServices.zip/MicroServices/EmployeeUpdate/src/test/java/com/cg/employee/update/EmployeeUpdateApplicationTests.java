package com.cg.employee.update;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeUpdateApplicationTests {

	@Test
	void contextLoads() {
	}

}
